#!/usr/bin/env bash
set -e

APP_DIR="$HOME/.local/share/log-scan"
BIN_DIR="$HOME/.local/bin"
DESKTOP_DIR="$HOME/.local/share/applications"
ICON_DIR="$HOME/.local/share/icons/hicolor/scalable/apps"
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"

if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3 is required. Install it with: sudo apt install python3"
  exit 1
fi

if ! python3 - <<'PY' >/dev/null 2>&1
import tkinter
PY
then
  echo "Tkinter is missing. Installing python3-tk requires sudo."
  sudo apt update
  sudo apt install -y python3-tk
fi

mkdir -p "$APP_DIR" "$BIN_DIR" "$DESKTOP_DIR" "$ICON_DIR"
cp "$SCRIPT_DIR/log_scan.py" "$APP_DIR/log_scan.py"
cp "$SCRIPT_DIR/logscan.svg" "$ICON_DIR/log-scan.svg"
chmod +x "$APP_DIR/log_scan.py"

cat > "$BIN_DIR/log-scan" <<EOF
#!/usr/bin/env bash
exec python3 "$APP_DIR/log_scan.py"
EOF
chmod +x "$BIN_DIR/log-scan"

cat > "$DESKTOP_DIR/log-scan.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=Log Scan
Comment=Scan logs for a selected Linux program
Exec=$BIN_DIR/log-scan
Icon=log-scan
Terminal=false
Categories=Utility;Development;
StartupNotify=true
EOF
chmod +x "$DESKTOP_DIR/log-scan.desktop"

if command -v update-desktop-database >/dev/null 2>&1; then
  update-desktop-database "$DESKTOP_DIR" >/dev/null 2>&1 || true
fi
if command -v gtk-update-icon-cache >/dev/null 2>&1; then
  gtk-update-icon-cache -f -t "$HOME/.local/share/icons/hicolor" >/dev/null 2>&1 || true
fi

echo
echo "Log Scan installed successfully."
echo "Open it from your applications menu or run: log-scan"
