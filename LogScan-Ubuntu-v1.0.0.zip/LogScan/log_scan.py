#!/usr/bin/env python3
import os
import re
import shlex
import signal
import subprocess
import threading
import time
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from pathlib import Path
from datetime import datetime, timedelta

APP_NAME = "Log Scan"
VERSION = "1.0.0"

ERROR_RE = re.compile(
    r"\b(error|failed|failure|fatal|critical|crash|segfault|exception|traceback|panic|denied|not found|core dumped)\b",
    re.IGNORECASE,
)
WARN_RE = re.compile(r"\b(warn|warning|deprecated|timeout|retry)\b", re.IGNORECASE)

MAX_FILE_SIZE = 8 * 1024 * 1024
MAX_MATCHES_PER_FILE = 250


class LogScanApp:
    def __init__(self, root):
        self.root = root
        self.root.title(f"{APP_NAME} {VERSION}")
        self.root.geometry("980x680")
        self.root.minsize(760, 520)

        self.program_path = tk.StringVar()
        self.status = tk.StringVar(value="Select a program to begin.")
        self.days = tk.IntVar(value=7)
        self.only_errors = tk.BooleanVar(value=False)
        self.capture_process = None
        self.stop_scan = threading.Event()

        self._build_ui()
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

    def _build_ui(self):
        outer = ttk.Frame(self.root, padding=12)
        outer.pack(fill="both", expand=True)

        title = ttk.Label(outer, text=APP_NAME, font=("Sans", 18, "bold"))
        title.pack(anchor="w")
        ttk.Label(
            outer,
            text="Select an Ubuntu/Linux program and scan related logs for errors and warnings.",
        ).pack(anchor="w", pady=(0, 12))

        select_frame = ttk.LabelFrame(outer, text="Program", padding=10)
        select_frame.pack(fill="x")

        row = ttk.Frame(select_frame)
        row.pack(fill="x")
        ttk.Entry(row, textvariable=self.program_path).pack(side="left", fill="x", expand=True)
        ttk.Button(row, text="Browse...", command=self.browse_program).pack(side="left", padx=(8, 0))

        options = ttk.Frame(select_frame)
        options.pack(fill="x", pady=(10, 0))
        ttk.Label(options, text="Scan last").pack(side="left")
        ttk.Spinbox(options, from_=1, to=90, width=5, textvariable=self.days).pack(side="left", padx=5)
        ttk.Label(options, text="days").pack(side="left")
        ttk.Checkbutton(options, text="Show only errors", variable=self.only_errors).pack(side="left", padx=(16, 0))

        buttons = ttk.Frame(outer)
        buttons.pack(fill="x", pady=10)
        self.scan_btn = ttk.Button(buttons, text="Scan Logs", command=self.start_scan)
        self.scan_btn.pack(side="left")
        self.launch_btn = ttk.Button(buttons, text="Launch & Capture", command=self.launch_and_capture)
        self.launch_btn.pack(side="left", padx=8)
        self.stop_btn = ttk.Button(buttons, text="Stop", command=self.stop_current, state="disabled")
        self.stop_btn.pack(side="left")
        ttk.Button(buttons, text="Clear", command=self.clear_output).pack(side="right")
        ttk.Button(buttons, text="Save Report...", command=self.save_report).pack(side="right", padx=8)

        notebook = ttk.Notebook(outer)
        notebook.pack(fill="both", expand=True)

        scan_tab = ttk.Frame(notebook)
        live_tab = ttk.Frame(notebook)
        notebook.add(scan_tab, text="Scan Results")
        notebook.add(live_tab, text="Live Capture")

        self.scan_text = tk.Text(scan_tab, wrap="word", font=("Monospace", 10), undo=False)
        scan_scroll = ttk.Scrollbar(scan_tab, orient="vertical", command=self.scan_text.yview)
        self.scan_text.configure(yscrollcommand=scan_scroll.set)
        self.scan_text.pack(side="left", fill="both", expand=True)
        scan_scroll.pack(side="right", fill="y")

        self.live_text = tk.Text(live_tab, wrap="word", font=("Monospace", 10), undo=False)
        live_scroll = ttk.Scrollbar(live_tab, orient="vertical", command=self.live_text.yview)
        self.live_text.configure(yscrollcommand=live_scroll.set)
        self.live_text.pack(side="left", fill="both", expand=True)
        live_scroll.pack(side="right", fill="y")

        self._configure_tags(self.scan_text)
        self._configure_tags(self.live_text)

        status_frame = ttk.Frame(outer)
        status_frame.pack(fill="x", pady=(8, 0))
        ttk.Label(status_frame, textvariable=self.status).pack(side="left")
        ttk.Label(status_frame, text=f"v{VERSION}").pack(side="right")

    @staticmethod
    def _configure_tags(widget):
        widget.tag_configure("error", foreground="#e74c3c")
        widget.tag_configure("warn", foreground="#d68910")
        widget.tag_configure("ok", foreground="#2e8b57")
        widget.tag_configure("header", font=("Monospace", 10, "bold"))
        widget.tag_configure("dim", foreground="#888888")

    def browse_program(self):
        path = filedialog.askopenfilename(title="Select program/executable")
        if path:
            self.program_path.set(path)
            self.status.set(f"Selected: {path}")

    def validate_program(self):
        raw = self.program_path.get().strip()
        if not raw:
            messagebox.showwarning(APP_NAME, "Select a program first.")
            return None
        path = Path(raw).expanduser()
        if not path.exists():
            messagebox.showerror(APP_NAME, f"Program not found:\n{path}")
            return None
        if path.is_dir():
            messagebox.showerror(APP_NAME, "Please select an executable file, not a folder.")
            return None
        return path.resolve()

    def clear_output(self):
        self.scan_text.delete("1.0", "end")
        self.live_text.delete("1.0", "end")
        self.status.set("Output cleared.")

    def start_scan(self):
        program = self.validate_program()
        if not program:
            return
        self.stop_scan.clear()
        self.scan_btn.config(state="disabled")
        self.stop_btn.config(state="normal")
        self.scan_text.delete("1.0", "end")
        self.status.set("Scanning logs...")
        threading.Thread(target=self.scan_worker, args=(program,), daemon=True).start()

    def scan_worker(self, program):
        name = program.name
        stem = program.stem
        since_days = max(1, int(self.days.get() or 7))
        since = datetime.now() - timedelta(days=since_days)
        results = []

        self.append_scan(f"Log Scan report for: {program}\n", "header")
        self.append_scan(f"Generated: {datetime.now().isoformat(sep=' ', timespec='seconds')}\n")
        self.append_scan(f"Window: last {since_days} day(s)\n\n", "dim")

        # journalctl: user and system journal, no sudo prompt
        journal_queries = [
            ["journalctl", "--user", "--since", f"{since_days} days ago", "--no-pager", "-o", "short-iso"],
            ["journalctl", "--since", f"{since_days} days ago", "--no-pager", "-o", "short-iso"],
        ]
        journal_seen = set()
        self.append_scan("== journalctl ==\n", "header")
        for cmd in journal_queries:
            if self.stop_scan.is_set():
                break
            try:
                proc = subprocess.run(cmd, text=True, capture_output=True, timeout=20)
                text = proc.stdout or ""
                for line in text.splitlines():
                    low = line.lower()
                    if name.lower() in low or stem.lower() in low or str(program).lower() in low:
                        if line in journal_seen:
                            continue
                        journal_seen.add(line)
                        if self.only_errors.get() and not ERROR_RE.search(line):
                            continue
                        results.append(("journalctl", line))
                        self.append_scan(line + "\n", self.classify(line))
            except FileNotFoundError:
                self.append_scan("journalctl is not available on this system.\n", "warn")
                break
            except subprocess.TimeoutExpired:
                self.append_scan("journalctl scan timed out.\n", "warn")
            except Exception as exc:
                self.append_scan(f"journalctl error: {exc}\n", "error")

        # Candidate log directories
        home = Path.home()
        candidates = [
            home / ".cache",
            home / ".local" / "share",
            home / ".config",
            Path("/var/log"),
            program.parent,
        ]
        keywords = {name.lower(), stem.lower()}
        self.append_scan("\n== Log files ==\n", "header")

        scanned_files = 0
        matched_files = 0
        for base in candidates:
            if self.stop_scan.is_set():
                break
            if not base.exists():
                continue
            try:
                for root, dirs, files in os.walk(base):
                    if self.stop_scan.is_set():
                        break
                    # Skip huge/noisy trees and hidden caches that are rarely logs
                    dirs[:] = [d for d in dirs if d not in {"node_modules", ".git", "Trash", "thumbnails", "pip", "npm"}]
                    root_path = Path(root)
                    for filename in files:
                        if self.stop_scan.is_set():
                            break
                        path = root_path / filename
                        low_path = str(path).lower()
                        suffix = path.suffix.lower()
                        likely_log = suffix in {".log", ".txt", ".out", ".err", ".rpt"} or "log" in filename.lower()
                        related_name = any(k and k in low_path for k in keywords)
                        if not (likely_log and related_name):
                            continue
                        try:
                            st = path.stat()
                            if st.st_size > MAX_FILE_SIZE or datetime.fromtimestamp(st.st_mtime) < since:
                                continue
                        except (OSError, ValueError):
                            continue

                        scanned_files += 1
                        count = self.scan_file(path, results)
                        if count:
                            matched_files += 1
                            if matched_files >= 80:
                                self.append_scan("\nReached the 80 matched-file safety limit.\n", "warn")
                                break
                    if matched_files >= 80:
                        break
            except PermissionError:
                self.append_scan(f"Permission denied while scanning {base}\n", "warn")
            except OSError as exc:
                self.append_scan(f"Could not scan {base}: {exc}\n", "warn")

        errors = sum(1 for _, line in results if ERROR_RE.search(line))
        warnings = sum(1 for _, line in results if WARN_RE.search(line) and not ERROR_RE.search(line))

        self.append_scan("\n== Summary ==\n", "header")
        self.append_scan(f"Matching entries: {len(results)}\n")
        self.append_scan(f"Errors/critical entries: {errors}\n", "error" if errors else "ok")
        self.append_scan(f"Warnings: {warnings}\n", "warn" if warnings else "ok")
        self.append_scan(f"Candidate log files inspected: {scanned_files}\n")

        if not results:
            self.append_scan("\nNo related errors or log entries were found in the selected time window.\n", "ok")

        self.root.after(0, lambda: self.finish_scan(len(results), errors))

    def scan_file(self, path, results):
        matches = 0
        try:
            with path.open("r", encoding="utf-8", errors="replace") as f:
                lines = f.readlines()[-5000:]
        except (OSError, UnicodeError):
            return 0

        selected = []
        for idx, line in enumerate(lines, 1):
            line = line.rstrip("\n")
            if not line.strip():
                continue
            is_error = bool(ERROR_RE.search(line))
            is_warn = bool(WARN_RE.search(line))
            if self.only_errors.get():
                if not is_error:
                    continue
            else:
                if not (is_error or is_warn):
                    continue
            selected.append((idx, line))
            if len(selected) >= MAX_MATCHES_PER_FILE:
                break

        if selected:
            self.append_scan(f"\n[{path}]\n", "header")
            for idx, line in selected:
                text = f"L{idx}: {line}"
                results.append((str(path), text))
                self.append_scan(text + "\n", self.classify(line))
                matches += 1
        return matches

    def finish_scan(self, count, errors):
        self.scan_btn.config(state="normal")
        if not self.capture_process:
            self.stop_btn.config(state="disabled")
        self.status.set(f"Scan complete. {count} matching entries, {errors} error/critical entries.")

    @staticmethod
    def classify(line):
        if ERROR_RE.search(line):
            return "error"
        if WARN_RE.search(line):
            return "warn"
        return None

    def append_scan(self, text, tag=None):
        self.root.after(0, self._append_text, self.scan_text, text, tag)

    def append_live(self, text, tag=None):
        self.root.after(0, self._append_text, self.live_text, text, tag)

    @staticmethod
    def _append_text(widget, text, tag=None):
        widget.insert("end", text, tag if tag else ())
        widget.see("end")

    def launch_and_capture(self):
        program = self.validate_program()
        if not program:
            return
        if self.capture_process and self.capture_process.poll() is None:
            messagebox.showinfo(APP_NAME, "A captured process is already running.")
            return

        self.live_text.delete("1.0", "end")
        self.append_live(f"Launching: {program}\n\n", "header")
        self.status.set("Program running. Capturing stdout/stderr...")
        self.stop_btn.config(state="normal")
        self.launch_btn.config(state="disabled")
        threading.Thread(target=self.capture_worker, args=(program,), daemon=True).start()

    def capture_worker(self, program):
        try:
            self.capture_process = subprocess.Popen(
                [str(program)],
                cwd=str(program.parent),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
                start_new_session=True,
                env=os.environ.copy(),
            )
            if self.capture_process.stdout:
                for line in self.capture_process.stdout:
                    self.append_live(line, self.classify(line))
            code = self.capture_process.wait()
            tag = "ok" if code == 0 else "error"
            self.append_live(f"\nProcess exited with code {code}.\n", tag)
        except PermissionError:
            self.append_live("Permission denied. Make sure the selected file is executable.\n", "error")
        except FileNotFoundError:
            self.append_live("The selected program could not be started.\n", "error")
        except Exception as exc:
            self.append_live(f"Launch error: {exc}\n", "error")
        finally:
            self.capture_process = None
            self.root.after(0, self.finish_capture)

    def finish_capture(self):
        self.launch_btn.config(state="normal")
        if self.scan_btn["state"] != "disabled":
            self.stop_btn.config(state="disabled")
        self.status.set("Capture finished.")

    def stop_current(self):
        self.stop_scan.set()
        proc = self.capture_process
        if proc and proc.poll() is None:
            try:
                os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
                self.append_live("\nStop requested...\n", "warn")
            except Exception as exc:
                self.append_live(f"\nCould not stop process: {exc}\n", "error")
        self.status.set("Stop requested.")

    def save_report(self):
        content = self.scan_text.get("1.0", "end").strip()
        if not content:
            messagebox.showinfo(APP_NAME, "There is no scan report to save yet.")
            return
        default = f"log-scan-{datetime.now().strftime('%Y%m%d-%H%M%S')}.txt"
        path = filedialog.asksaveasfilename(
            title="Save report",
            defaultextension=".txt",
            initialfile=default,
            filetypes=[("Text files", "*.txt"), ("All files", "*")],
        )
        if path:
            try:
                Path(path).write_text(content + "\n", encoding="utf-8")
                self.status.set(f"Report saved: {path}")
            except OSError as exc:
                messagebox.showerror(APP_NAME, f"Could not save report:\n{exc}")

    def on_close(self):
        self.stop_scan.set()
        proc = self.capture_process
        if proc and proc.poll() is None:
            try:
                os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
                time.sleep(0.1)
            except Exception:
                pass
        self.root.destroy()


def main():
    root = tk.Tk()
    try:
        style = ttk.Style(root)
        if "clam" in style.theme_names():
            style.theme_use("clam")
    except tk.TclError:
        pass
    LogScanApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
