#!/usr/bin/env bash
set -e
rm -rf "$HOME/.local/share/log-scan"
rm -f "$HOME/.local/bin/log-scan"
rm -f "$HOME/.local/share/applications/log-scan.desktop"
rm -f "$HOME/.local/share/icons/hicolor/scalable/apps/log-scan.svg"
echo "Log Scan uninstalled."
