# Log Scan

Simple log scanner for Ubuntu/Linux.

## Features

- Select any executable from the UI.
- Search recent `journalctl` entries related to the executable name/path.
- Search common log locations such as `~/.cache`, `~/.local/share`, `~/.config`, `/var/log`, and the program folder.
- Highlights common errors, crashes, warnings, exceptions, segfaults and permission failures.
- Optional **Show only errors** filter.
- **Launch & Capture** starts the selected program and captures its stdout/stderr in real time.
- Save the scan report to a text file.
- Stop a captured process from the UI.

## Install on Ubuntu

Open a terminal inside this folder and run:

```bash
chmod +x install.sh run.sh uninstall.sh
./install.sh
```

The installer uses your user account and only asks for `sudo` if `python3-tk` is missing.

After installation, open **Log Scan** from the Ubuntu applications menu.

## Run without installing

```bash
chmod +x run.sh
./run.sh
```

If Tkinter is missing:

```bash
sudo apt install python3-tk
```

## Notes

`Log Scan` does not modify the selected application. System logs that require root permissions may not be readable unless your user already has access to them.
